function  driver( chap )


if nargin == 0
    chap = 'chap2';
end
    

switch chap
    case 'chap2'
        fig2_2()
        fig2_4()
        fig2_7_2_8()
        fig2_9()
        fig2_10()
        fig2_11()
end

end

