function [U] = CNS(x,t,U0,theta)

%CRANKNIROLSONSCHEME compute the FD by CrankNirolson Scheme

% [U] = crankNirolsonScheme(t,x,theta) where theta is the parameter

% when theta = 0, it is like explicit, when theta = 1, it is Implicit



if nargin < 4

    theta = 1/2;

end



%% initial

U = zeros(size(t(:),1),size(x(:),1));

U(1,:) = U0;



mu = (t(2)-t(1))/((x(2)-x(1))^2);



%% construct the differential matrix D

D = sparse(toeplitz([-2 1 zeros(1,size(U,2)-2)]));

D(1,:) = 0;D(end,:) = 0;



%% compute the heat equation

for n = 2:size(t(:),1)

    U(n,2:end-1) = (eye(size(x(:),1)-2) - mu*theta*D(2:end-1,2:end-1)) \...
        ((eye(size(x(:),1)-2) + (1-theta) * mu * D(2:end-1,2:end-1)) *U(n-1,2:end-1)');

end
end