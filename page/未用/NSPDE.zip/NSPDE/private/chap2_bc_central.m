function [U, x] = chap2_bc_central(nx, nt, dt, theta, u0, bcflag)
%CHAP2_BC_CENTRAL imposed bounary condition by central difference half-way.
%   [U, x] = CHAP2_BC_CENTRAL(nx, nt, dt, theta, u0, bcflag), where nx = 1/dx,
%   dt  is the time step and nt the number of step, theta is the weight and u0
%   is a function handle for inital condition. 
%   bcflag is the flag for boundary condition.
%
%   bcflag = [0,0] u_x(0,t) = u_x(1,t) =0;
%   bcflag = [0,1] u_x(0,t) = u(1,t) = 0;
%   bcflag = [1,0] u(0,t) = u_x(1,t) = 0;
%   bcflag = [1,1] u(0,t) = u(1,t) = 0;

% $Date: 14-Sep-2018, Time: 19:04:33$
% Copyright (c) Guanjie Wang

if ( (bcflag(1) == 0) && (bcflag(2) ~= 0) )
    dx = 1./(nx-0.5);
    mu = dt/dx^2;
    x = linspace(-0.5*dx,1,nx+1);
elseif ( (bcflag(1) ~= 0) && (bcflag(2) == 0) )
    dx = 1./(nx-0.5);
    mu = dt/dx^2;
    x = linspace(0,1+.5*dx,nx+1);
elseif ( (bcflag(1) == 0) && (bcflag(2) == 0) )
    dx = 1./(nx-1);
    mu = dt/dx^2;
    x = linspace(-.5*dx,1+.5*dx,nx+1);
elseif ( (bcflag(1) ~= 0) && (bcflag(2) ~= 0) )
    dx = 1./nx;
    mu = dt/dx^2;
    x = linspace(0,1,nx+1);
end

x = x(:);
U = zeros(nx+1, nt+1);

U(:,1) = u0(x);
U(1,:) = u0(x(1));
U(end,:) = u0(x(end));

[A,B] = diffmat_heat(nx, theta, mu);

%% impose boundary condition
if (bcflag(1) ~= 0)
    A = A(2:end,2:end);
    B = B(2:end,2:end);
    U = U(2:end,:);
else
    A(1,1) = 1; 
    A(1,2) = -1;
    B(1,:) = 0;
    U(1,1) = U(2,1);
   
end

if bcflag(2) ~= 0
    A = A(1:end-1,1:end-1);
    B = B(1:end-1,1:end-1);
    U = U(1:end-1,:);
else
    A(end,end) = 1; 
    A(end,end-1) = -1;
    B(end,:) = 0; 
    U(end,1) = U(end-1,1);
end

%% stepping
for n = 1:nt
    b = B*U(:,n);
    U(:,n+1) = A\b;
end

U0 = zeros(1,nt+1);
Un = zeros(1,nt+1);

if bcflag(1) ~= 0
    U = [U0;U];
end

if bcflag(2) ~= 0
    U = [U;Un];
end



end