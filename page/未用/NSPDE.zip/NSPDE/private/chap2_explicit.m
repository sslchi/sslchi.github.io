function [U,x] = chap2_explicit(nx, nt, dt, u0)
%CHAP2_EXPLICIT Solve heat equation by explicit method.
% [U,x] = CHAP2_EXPLICIT(nx, nt, dt, theta, u0), where nx = 1/dx, dt  is the
% time step and nt the number of step, u0 is a function handle for inital
% condition.
%

% $Date: 14-Sep-2018, Time: 19:04:33$
% Copyright (c) Guanjie Wang

dx = 1./nx;
mu = dt/dx^2;

x = linspace(0,1,nx+1);
x = x(:); 
U = zeros(nx+1, nt+1);

U(:,1) = u0(x);
U(1,:) = u0(x(1));
U(end,:) = u0(x(end));

%% stepping
for n = 1:nt
    U(2:end-1,n+1) = U(2:end-1,n) + mu*(U(3:end,n)-2*U(2:end-1,n)+U(1:end-2,n));  
end


end