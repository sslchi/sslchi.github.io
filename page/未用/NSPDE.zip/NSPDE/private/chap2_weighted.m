function [U,x] = chap2_weighted(nx, nt, dt, theta, u0)
%CHAP2_WEIGHTED Solve heat equation by weighted average method.
% [U,x] = CHAP2_WEIGHTED(nx, nt, dt, theta, u0), where nx = 1/dx, dt  is the
% time step and nt the number of step, theta is the weight and u0 is a function
% handle for inital condition.  
% The boundary condition is u(0,t) = u(1,t)= 0.
%

% $Date: 14-Sep-2018, Time: 19:04:33$
% Copyright (c) Guanjie Wang

dx = 1./nx;
mu = dt/dx^2;

x = linspace(0,1,nx+1);
x = x(:);
U = zeros(nx+1, nt+1);

U(:,1) = u0(x);

[A,B] = diffmat_heat(nx, theta, mu);

%% impose boundary condition
A = A(2:end-1,2:end-1);
B = B(2:end-1,2:end-1);
U = U(2:end-1,:);
U1 = zeros(1,nt+1);
Un = zeros(1,nt+1);
%% stepping
for n = 1:nt
    b = B*U(:,n);
    U(:,n+1) = A\b;
end

U = [U1;U;Un];

end