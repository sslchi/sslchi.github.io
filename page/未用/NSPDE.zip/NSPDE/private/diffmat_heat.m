function [A,B] = diffmat_heat(nx, theta, mu)
%DIFFMAT_HEAT Give differential matrix of heat equation.
%[A,B] = DIFFMAT_HEAT(nx, theta, mu)

a1 = (1+2*theta*mu)*ones(1,nx+1);
a2 = -theta*mu*ones(1,nx);
a3 = -theta*mu*ones(1,nx);
A = diag(a1) + diag(a2,1) + diag(a3,-1);

b1 = (1-2*(1-theta)*mu)*ones(1,nx+1);
b2 = (1-theta)*mu*ones(1,nx);
b3 = (1-theta)*mu*ones(1,nx);

B = diag(b1) + diag(b2,1) + diag(b3,-1);

A = sparse(A);
B = sparse(B);

end