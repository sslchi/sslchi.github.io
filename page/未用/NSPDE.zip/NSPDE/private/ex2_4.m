function ex2_4()

close all
u0 = @(x) 2.*x.*((x<=0.5)& (x>=0)) + (2-2.*x).*((x>0.5) & (x<=1));

nx1 = 10;
dx1 = 1/nx1;
dt1 = 0.25*dx1^2;
nt1 = round(1/dt1);
x1 = linspace(0,1,nx1+1);
En1 = zeros(nt1,1);
 
%% compute exact solution
m = 1:1000;
am = 8./(m.^2*pi^2).*sin(0.5*m*pi);
u = @(x,t) (am*(exp(-m'.^2*pi^2*t).*sin(pi.*m'.*x)))'; % x should be a row vector 


%% numerical solution
U1 = chap2_explicit(nx1, nt1, dt1, u0);

%% compute errors
for i = 1:nt1
    En1(i) = max(abs(U1(:,i+1) - u(x1, i*dt1)));
end



%% figure plot
plot(dt1*(1:nt1),log10(En1),'-')

xlabel('$t_n$','Interpreter','latex')
ylabel('$\log_{10}E_n$','Interpreter','latex')
savefig('ex2_4')
end