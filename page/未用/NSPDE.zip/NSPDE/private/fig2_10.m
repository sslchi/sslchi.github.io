function fig2_10()

close all
u0 = @(x) 1-x.^2;

%% compute exact solution
m = 1:2:31;
am = 32./(m.^3*pi^3).*sin(0.5*m*pi);
u = @(x,t) (am*(exp(-.25*m'.^2*pi^2*t).*cos(.5*pi.*m'.*x)))'; % x should be a row vector 
 
nx = 10;
dt = 1./nx^2;
nt = round(1./dt);
[U1,x1] = chap2_bc_forward(nx, nt, dt, 1/2, u0,[0,1]);
[U2,x2] = chap2_bc_central(nx, nt, dt, 1/2, u0,[0,1]);
[U3,x3] = chap2_bc_fictious(nx, nt, dt, 1/2, u0,[0,1]);



En1 = zeros(nt,1);
En2 = zeros(nt,1);
En3 = zeros(nt,1);
for ii = 1:nt
   En1(ii) = max(abs(U1(:,ii+1)- u(x1(:)',ii*dt)));
   En2(ii) = max(abs(U2(:,ii+1)- u(x2(:)',ii*dt)));
   En3(ii) = max(abs(U3(:,ii+1)- u(x3(:)',ii*dt)));
end


plot((1:nt)./nt,log10(En1),'-')
hold on
plot((1:nt)./nt,log10(En2),'-')
plot((1:nt)./nt,log10(En3),'-')

xlabel('$t_n$','Interpreter','latex')
ylabel('$\log_{10}E_n$','Interpreter','latex')

savefig('fig2_10')

end