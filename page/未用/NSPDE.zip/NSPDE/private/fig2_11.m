function fig2_11()
close all

nx = 10;
dx = 1./nx;
dt = .5*dx^2;
nt = round(1/dt);

dx3 = 1./(nx-1);
dt3 = .5*dx3^2;
nt3 = round(1/dt3);

En1 = zeros(1,nt);
En2 = zeros(1,nt);
En3 = zeros(1,nt3);
%% compute exact solution
u0 = @(x) 1-x.^2;

nf = 15;
m = 1:nf;
am = zeros(1,nf);
[x,w] = chebpts(5*nf);

for ii = 1:nf
    am(ii) = w*((1-x.^2).*cos(ii*pi.*x));
end
a0 = w*(1-x.^2);
u = @(x,t) .5*a0+(am*(exp(-m'.^2*pi^2*t).*cos(pi.*m'.*x)))'; % x should be a row vector 

%% numerical solution for pde
[U1,x1] = chap2_bc_fictious(nx, nt, dt, .5, u0,[0,0]);
[U2,x2] = chap2_bc_forward(nx, nt, dt, .5, u0,[0,0]);
U3= chap2_bc_conservation(nx, nt3, dt3, .5,u0);
for ii = 1:nt
    En1(ii) = max(abs(U1(:,ii+1)-u(x1(:)',ii*dt)));
    En2(ii) = max(abs(U2(:,ii+1)-u(x2(:)',ii*dt)));
end

for ii = 1:nt3
    uii = mean(nx, @(x)u(x',ii*dt3)) ;
    En3(ii) = max( abs( U3(2:end-1,ii+1)-  uii(2:end-1) ) );
end

plot(dt*(1:nt),log10(En1))
hold on
plot(dt*(1:nt),log10(En2))
plot(dt3*(1:nt3),log10(En3))

xlabel('$t_n$','Interpreter','latex')
ylabel('$\log_{10}E_n$','Interpreter','latex')


savefig('fig2_11')

end

%% ============================ sub functions ================================== 

function U = chap2_bc_conservation(nx, nt, dt, theta, u0)
%CHAP1_BC_CONSERVATION imposed bounary condition by conservation law.


% $Date: 14-Sep-2018, Time: 19:04:33$
% Copyright (c) Guanjie Wang


dx = 1./(nx-1);
mu = dt/dx^2;
U = zeros(nx+1, nt+1);

for ii = 1:(nx-1)
    
    [x1, w1] = chebpts(5,[(ii-1)*dx, ii*dx]);
    U(ii+1,1) = w1*u0(x1)/dx;
    
end

U(1,1) = U(2,1);
U(end,1) = U(end-1,1);

[A,B] = diffmat_heat(nx, theta, mu);
%% impose boundary condition
A(1,1) = 1;
A(1,2) = -1;
B(1,:) = 0;
A(end,end) = 1;
A(end,end-1) = -1;
B(end,:) = 0;

%% stepping
for n = 1:nt
    b = B*U(:,n);
    U(:,n+1) = A\b;
end

end


function u1 = mean(nx,u0)

dx = 1./(nx-1);
u1 = zeros(nx+1,1);

for ii = 0:nx
    [x1, w1] = chebpts(50,[(ii-1)*dx, ii*dx]);
    u1(ii+1,1) = w1*u0(x1)/dx;
end

end


