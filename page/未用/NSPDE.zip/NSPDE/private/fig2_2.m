function fig2_2
close all

u0 = @(x) 2.*x.*((x<=0.5)& (x>=0)) + (2-2.*x).*((x>0.5) & (x<=1));

nx = 20;
nt = 50;
dt1 = 0.0012;
dt2 = 0.0013;

%% compute exact solution
m = 1:1000;
am = 8./(m.^2*pi^2).*sin(0.5*m*pi);
u = @(x,t) (am*(exp(-m'.^2*pi^2*t).*sin(pi.*m'.*x)))'; % x should be a row vector 

x = linspace(0,1,nx+1);
%% dt = 0.0012
U = chap2_explicit(nx, nt, dt1, u0);

subplot(4,2,1)
plot(x,U(:,1),'.-');
hold on
plot(x,u(x, 0*dt1),'r-')    

subplot(4,2,3)
plot(x,U(:,1+1),'.-');
hold on
plot(x,u(x, 1*dt1),'r-') 

subplot(4,2,5)
plot(x,U(:,25+1),'.-');
hold on
plot(x,u(x, 25*dt1),'r-')   


subplot(4,2,7)
plot(x,U(:,50+1),'.-');
hold on
plot(x,u(x, 50*dt1),'r-') 

%% dt = 0.0013
U = chap2_explicit(nx, nt, dt2, u0);

subplot(4,2,2)
plot(x,U(:,1),'.-');
hold on
plot(x,u(x, 0*dt2),'r-')    

subplot(4,2,4)
plot(x,U(:,1+1),'.-');
hold on
plot(x,u(x, 1*dt2),'r-') 

subplot(4,2,6)
plot(x,U(:,25+1),'.-');
hold on
plot(x,u(x, 25*dt2),'r-')   


subplot(4,2,8)
plot(x,U(:,50+1),'.-');
hold on
plot(x,u(x, 50*dt2),'r-') 

savefig('fig2_2')

end

