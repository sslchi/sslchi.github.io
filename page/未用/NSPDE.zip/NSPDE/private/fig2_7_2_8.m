function fig2_7_2_8()

close all
u0 = @(x) x.*(1-x);

%% compute exact solution
m = 1:10;
am = 4./(m.^3*pi^3).*(1-cos(m*pi));
u = @(x,t) (am*(exp(-m'.^2*pi^2*t).*sin(pi.*m'.*x)))';  % x should be a row vector 

E1 = zeros(14,0);
E2 = zeros(14,0);
E3 = zeros(14,0);
E4 = zeros(14,0);
E5 = zeros(14,0);
E6 = zeros(14,0);
E7 = zeros(14,0);
J = [10:16,18,20,25,30,40,60,80];

k1 = zeros(14,0);
k2 = zeros(14,0);
k3 = zeros(14,0);
k4 = zeros(14,0);
k5 = zeros(14,0);
k6 = zeros(14,0);
k7 = zeros(14,0);


for ii = 1:14
   nx = J(ii);
   dx = 1/nx;
   dt = 0.5*dx^2;
   nt = round(1./dt);
   
   
   U1 = chap2_weighted(nx, nt, dt, 0, u0);
   U2 = chap2_weighted(nx, nt, dt, 0.5, u0);
   x = linspace(0,1,nx+1);
   Ea = []; Eb = [];
   
   for i = round(0.1/dt):nt
       Ue = u(x, i*dt);
       Ea =[Ea, max(abs(U1(:,i+1) - Ue))]; %#ok<AGROW>
       Eb =[Eb, max(abs(U2(:,i+1) - Ue))]; %#ok<AGROW>
   end
   k1(ii) = 1./dx/dt;
   k2(ii) = 1./dx/dt;
   E1(ii) = max(Ea);
   E2(ii) = max(Eb);
    
   dt = 0.05*dx;
   nt = round(1./dt);
   U3 = chap2_weighted(nx, nt, dt, 0.5, u0);
   Ea = [];
   
   for i = round(0.1/dt):nt
       Ue = u(x, i*dt);
       Ea =[Ea, max(abs(U3(:,i+1) - Ue))]; %#ok<AGROW>
   end
   k3(ii) = 1./dx/dt;
   E3(ii) = max(Ea);
   
   
   dt = 5*dx^2;
   nt = round(1./dt);
   U4 = chap2_weighted(nx, nt, dt, 0.5, u0);
   U5 = chap2_weighted(nx, nt, dt, 1, u0);
   Ea = []; Eb = [];
   
   for i = round(0.1/dt):nt
       Ue = u(x, i*dt);
       Ea =[Ea, max(abs(U4(:,i+1) - Ue))]; %#ok<AGROW>
       Eb =[Eb, max(abs(U5(:,i+1) - Ue))]; %#ok<AGROW>
   end
   
   k4(ii) = 1./dx/dt;
   k5(ii) = 1./dx/dt;
   E4(ii) = max(Ea);
   E5(ii) = max(Eb);
   
   
   dt = 0.5*dx;
   nt = round(1./dt);
   U4 = chap2_weighted(nx, nt, dt, 0.5, u0);
   U5 = chap2_weighted(nx, nt, dt, 1, u0);
   Ea = []; Eb = [];
   
   for i = round(0.1/dt):nt
       Ue = u(x, i*dt);
       Ea =[Ea, max(abs(U4(:,i+1) - Ue))]; %#ok<AGROW>
       Eb =[Eb, max(abs(U5(:,i+1) - Ue))]; %#ok<AGROW>
   end
   k6(ii) = 1./dx/dt;
   k7(ii) = 1./dx/dt;
   E6(ii) = max(Ea);
   E7(ii) = max(Eb);
   
end


semilogx(J,log10(E1),'-o');
hold on 
semilogx(J,log10(E2),'-x');
semilogx(J,log10(E3),':x');
semilogx(J,log10(E4),'-+');
semilogx(J,log10(E6),':+');
semilogx(J,log10(E5),'-*');
semilogx(J,log10(E7),'--*');
hold off
xlabel('$J$','Interpreter','latex')
ylabel('$\log_{10}E_n$','Interpreter','latex')

legend({'$\theta=0,\mu=\frac{1}{2}$',...
    '$\theta=\frac{1}{2},\mu=\frac{1}{2}$',...
    '$\theta=\frac{1}{2},\nu=\frac{1}{20}$',...
    '$\theta=\frac{1}{2},\mu=5$',...
    '$\theta=\frac{1}{2},\nu=\frac{1}{2}$',...
    '$\theta=1,\mu=5$',...
    '$\theta=1,\nu=\frac{1}{2}$',...
},'Interpreter','latex','FontSize',12,'Location','Best')


savefig('fig2_7')

figure
semilogx(k1,log10(E1),'-o');
hold on 
semilogx(k2,log10(E2),'-x');
semilogx(k3,log10(E3),':x');
semilogx(k4,log10(E4),'-+');
semilogx(k6,log10(E6),':+');
semilogx(k5,log10(E5),'-*');
semilogx(k7,log10(E7),'--*');
xlabel('$1/(\Delta x\Delta t)$','Interpreter','latex')
ylabel('$\log_{10}E_n$','Interpreter','latex')
hold off
legend({'$\theta=0,\mu=\frac{1}{2}$',...
    '$\theta=\frac{1}{2},\mu=\frac{1}{2}$',...
    '$\theta=\frac{1}{2},\nu=\frac{1}{20}$',...
    '$\theta=\frac{1}{2},\mu=5$',...
    '$\theta=\frac{1}{2},\nu=\frac{1}{2}$',...
    '$\theta=1,\mu=5$',...
    '$\theta=1,\nu=\frac{1}{2}$',...
},'Interpreter','latex','FontSize',12,'Location','Best')
savefig('fig2_8')

end