function fig2_9()
close all

u0 = @(x) 1.*(x==0.5);


nx = 20;
dx = 1/nx;
dt1 = 1*dx^2;
dt2 = 2*dx^2;
theta = 0.5;
nt = 10;

x = linspace(0,1,nx+1);

U1 = chap2_weighted(nx, nt, dt1, theta, u0);
U2 = chap2_weighted(nx, nt, dt2, theta, u0);


subplot(4,2,1)
plot(x,U1(:,1),'.-');
hold on 
plot(x,0*x,'-k')
box off

subplot(4,2,3)
plot(x,U1(:,1+1),'.-');
hold on 
plot(x,0*x,'-k')
box off

subplot(4,2,5)
plot(x,U1(:,2+1),'.-');
hold on 
plot(x,0*x,'-k')
box off   

subplot(4,2,7)
plot(x,U1(:,10+1),'.-');
hold on 
plot(x,0*x,'-k')
box off

subplot(4,2,2)
plot(x,U2(:,1),'.-');
hold on 
plot(x,0*x,'-k')
box off  

subplot(4,2,4)
plot(x,U2(:,1+1),'.-');
hold on 
plot(x,0*x,'-k')
box off

subplot(4,2,6)
plot(x,U2(:,2+1),'.-');
hold on 
plot(x,0*x,'-k')
box off

subplot(4,2,8)
plot(x,U2(:,10+1),'.-');
hold on 
plot(x,0*x,'-k')
box off



end