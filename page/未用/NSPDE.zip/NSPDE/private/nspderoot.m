function out = nspderoot()

out = fileparts(which('nspderoot'));

out = out(1:end-7);

end