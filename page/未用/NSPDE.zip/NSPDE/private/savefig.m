function savefig(name)

currDir = pwd;

insDir = nspderoot();
figDir = fullfile(insDir,'figure');

cd(figDir)
saveas(gcf,name,'epsc2')

cd(currDir);

end